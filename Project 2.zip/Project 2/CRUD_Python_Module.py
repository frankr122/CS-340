# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU1234' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            else:
                return False
        except Exception as e:
            print("Create failed",e)
            return False

    # Create method to implement the R in CRUD.
    def read(self,query):
        try:
            if query is not None:
                cursor=self.collection.find(query)
                return list(cursor)
            else:
                return []
            
        except Exception as e:
            print("Read failed",e)
            return []
        
    # Create method to implement the U in CRUD.
    def update(self, query, new_values):
        try:
            if query is not None and new_values is not None:
                # Use $set to update fields
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            else:
                return 0
        except Exception as e:
            print("Update failed", e)
            return 0

    # Create method to implement the D in CRUD.
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)
                return result.deleted_count
            else:
                return 0
        except Exception as e:
            print("Delete failed", e)
            return 0